# SmartFin-AI-Based-Financial-Forecasting-Expense-Management
Developed an AI-driven personal finance system using a hybrid LSTM–Prophet model to forecast expenses and stock price trends. • Implemented automated expense categorization into Needs, Wants, and Savings based on the 50/30/20 budgeting rule. 
