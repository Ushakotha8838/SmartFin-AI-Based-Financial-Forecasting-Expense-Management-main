import pandas as pd
import yfinance as yf
import os

# Load stock list (from your provided CSV)
df = pd.read_csv("nifty150.csv")
symbols = df['symbol'].tolist()

# Folder to store CSV data
os.makedirs("stock_data", exist_ok=True)

for symbol in symbols:
    try:
        print(f"Fetching data for {symbol}...")
        ticker = yf.Ticker(f"{symbol}.NS")
        hist = ticker.history(period="2y")
        if hist.empty:
            print(f"⚠️ No data for {symbol}, skipping...")
            continue
        hist.to_csv(f"stock_data/{symbol}.csv")
    except Exception as e:
        print(f"❌ Failed for {symbol}: {e}")

print("✅ All stock data saved to stock_data/")
