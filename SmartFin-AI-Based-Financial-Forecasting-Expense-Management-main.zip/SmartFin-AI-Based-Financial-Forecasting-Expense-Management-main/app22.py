from flask import Flask, render_template, request
import pandas as pd
import pdfplumber
import PyPDF2
import sqlite3
import os
from datetime import datetime
import yfinance as yf
import re

app = Flask(__name__)
UPLOAD_FOLDER = 'uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

def create_db():
    conn = sqlite3.connect('transactions.db')
    c = conn.cursor()
    c.execute('''CREATE TABLE IF NOT EXISTS transactions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        date TEXT, details TEXT, debit REAL, credit REAL,
        balance REAL, category TEXT, file_name TEXT
    )''')
    conn.commit()
    conn.close()

create_db()

@app.route('/')
def upload_file():
    return render_template('aa.html')

@app.route('/upload', methods=['POST'])
def upload_bank_statement():
    if 'file' not in request.files:
        return 'No file part'
    file = request.files['file']
    pdf_password = request.form.get('password')
    if file.filename == '':
        return 'No selected file'

    filepath = os.path.join(app.config['UPLOAD_FOLDER'], file.filename)
    file.save(filepath)

    try:
        ext = os.path.splitext(file.filename)[1].lower()
        if ext == '.csv':
            data = pd.read_csv(filepath, encoding='utf-8', engine='python')
        elif ext in ['.xlsx', '.xls']:
            data = pd.read_excel(filepath)
        elif ext == '.txt':
            data = pd.read_csv(filepath, delimiter=',', encoding='utf-8', engine='python')
        elif ext == '.pdf':
            if pdf_password:
                unlocked_path = unlock_pdf(filepath, pdf_password)
                if not unlocked_path:
                    return 'Incorrect PDF password or unable to unlock the file.'
                data = extract_table_from_pdf(unlocked_path)
            else:
                data = extract_table_from_pdf(filepath)
            if data is None:
                return 'Could not extract a valid table or text from the PDF.'
        else:
            return 'Unsupported file format.'

        data.columns = [col.lower().strip() for col in data.columns]
        parsed_data = data[['date', 'details', 'debit', 'credit', 'balance']]
        categorized_data = detect_recurring_transactions(parsed_data)
        save_to_db(categorized_data, file.filename)
        savings, needs, wants = calculate_summary(categorized_data)
        market_data = get_market_data_with_gold_and_stocks()
        investment_tip = generate_investment_tip(savings, market_data)

        records = categorized_data.to_dict(orient='records')
        return render_template('rr.html', records=records, savings=savings, needs=needs, wants=wants, investment_tip=investment_tip, market_data=market_data)

    except Exception as e:
        return f'Error processing file: {str(e)}'

def unlock_pdf(filepath, password):
    try:
        with open(filepath, 'rb') as f:
            reader = PyPDF2.PdfReader(f)
            if reader.is_encrypted:
                reader.decrypt(password)
                writer = PyPDF2.PdfWriter()
                for page in reader.pages:
                    writer.add_page(page)
                unlocked_path = filepath.replace('.pdf', '_unlocked.pdf')
                with open(unlocked_path, 'wb') as out:
                    writer.write(out)
                return unlocked_path
            return filepath
    except Exception as e:
        print("PDF unlock error:", e)
        return None

def extract_table_from_pdf(filepath):
    try:
        with pdfplumber.open(filepath) as pdf:
            all_tables = []
            all_lines = []

            for page in pdf.pages:
                tables = page.extract_tables()
                for table in tables:
                    df = pd.DataFrame(table[1:], columns=table[0])
                    if 'Date' in df.columns and 'Details' in df.columns:
                        df.columns = [c.strip().lower() for c in df.columns]
                        all_tables.append(df)
                text = page.extract_text()
                if text:
                    all_lines.extend(text.split('\\n'))

        if all_tables:
            return pd.concat(all_tables, ignore_index=True)

        transactions = []
        pattern = re.compile(
            r"(\\d{2}[/-]\\d{2}[/-]\\d{2,4})\\s+(.*?)\\s+([\\d,]+\\.\\d{2})?\\s*([\\d,]+\\.\\d{2})?\\s*([\\d,]+\\.\\d{2})?"
        )

        for line in all_lines:
            match = pattern.search(line)
            if match:
                date = match.group(1).replace('/', '-')
                details = match.group(2)
                debit = match.group(3) or ''
                credit = match.group(4) or ''
                balance = match.group(5) or ''
                transactions.append({
                    'date': date.strip(),
                    'details': details.strip(),
                    'debit': debit.replace(',', ''),
                    'credit': credit.replace(',', ''),
                    'balance': balance.replace(',', '')
                })

        if transactions:
            return pd.DataFrame(transactions)

        return None
    except Exception as e:
        print(f"PDF extraction error: {str(e)}")
        return None

def detect_recurring_transactions(df):
    df['date'] = pd.to_datetime(df['date'], errors='coerce', dayfirst=True)
    df = df.dropna(subset=['date']).sort_values('date')
    recurring = []
    for detail in df['details'].unique():
        dates = df[df['details'] == detail]['date'].sort_values().tolist()
        if len(dates) >= 2:
            intervals = [(dates[i+1] - dates[i]).days for i in range(len(dates)-1)]
            if all(30 <= d <= 45 for d in intervals):
                recurring.append(detail)
    df['category'] = df['details'].apply(lambda x: 'Need' if x in recurring else 'Want')
    return df

def save_to_db(df, file_name):
    conn = sqlite3.connect('transactions.db')
    c = conn.cursor()
    for _, row in df.iterrows():
        c.execute('''INSERT INTO transactions (date, details, debit, credit, balance, category, file_name)
                     VALUES (?, ?, ?, ?, ?, ?, ?)''',
            (row['date'].strftime('%Y-%m-%d'), row['details'], row['debit'], row['credit'],
             row['balance'], row['category'], file_name))
    conn.commit()
    conn.close()

def calculate_summary(df):
    df['debit'] = pd.to_numeric(df['debit'], errors='coerce').fillna(0)
    df['credit'] = pd.to_numeric(df['credit'], errors='coerce').fillna(0)
    total_debit = df['debit'].sum()
    total_credit = df['credit'].sum()
    needs = df[df['category'] == 'Need']['debit'].sum()
    wants = df[df['category'] == 'Want']['debit'].sum()
    savings = total_credit - total_debit
    return savings, needs, wants

def get_stock_changes():
    tickers = {
        'HDFCBANK.NS': 'Banking', 'ICICIBANK.NS': 'Banking',
        'RELIANCE.NS': 'Energy', 'ONGC.NS': 'Energy',
        'TCS.NS': 'Tech', 'INFY.NS': 'Tech',
        'TATAMOTORS.NS': 'Auto', 'MARUTI.NS': 'Auto'
    }
    perf = {}
    for ticker, sector in tickers.items():
        try:
            stock = yf.Ticker(ticker)
            hist = stock.history(period='5d')  # Increased from 2d to 5d
            if len(hist) >= 2:
                prev = hist['Close'].iloc[-2]
                curr = hist['Close'].iloc[-1]
                change = ((curr - prev) / prev) * 100
                perf.setdefault(sector, []).append(change)
        except Exception as e:
            print(f"Stock error: {e}")
    return {s: round(sum(v)/len(v), 2) for s, v in perf.items() if v}

def get_live_gold_price():
    return 6000  # Still mocked

def get_market_data_with_gold_and_stocks():
    return {
        'gold_price_today': get_live_gold_price(),
        'gold_price_last_week': 5850,
        'sector_changes': get_stock_changes()
    }

def generate_investment_tip(savings, market):
    sector_data = market.get('sector_changes', {})
    if not sector_data:
        return "⚠ Market data not available. Showing general tip."

    top_sector = max(sector_data, key=sector_data.get, default=None)
    top_change = sector_data.get(top_sector, 0)

    if savings <= 0:
        return "You have negative savings. Focus on reducing expenses before investing."
    if savings < 1000:
        return "Start with small SIPs or a liquid fund."
    if savings < 3000:
        if market['gold_price_today'] > market['gold_price_last_week']:
            return "💡 Gold prices are up. Consider starting a digital gold SIP."
        return "Use short-term RD or hybrid mutual fund."
    if top_sector:
        direction = "↑" if top_change >= 0 else "↓"
        return f"{top_sector} sector moved {direction}{abs(top_change):.2f}%. Consider stocks or ETFs in this area."
    return "Invest in balanced funds or blue-chip equity like HDFC, Infosys."

@app.route('/view')
def view_transactions():
    conn = sqlite3.connect('transactions.db')
    df = pd.read_sql_query("SELECT * FROM transactions", conn)
    conn.close()
    savings, needs, wants = calculate_summary(df)
    records = df.to_dict(orient='records')
    market_data = get_market_data_with_gold_and_stocks()
    investment_tip = generate_investment_tip(savings, market_data)
    return render_template('rr.html', records=records, savings=savings, needs=needs, wants=wants, investment_tip=investment_tip, market_data=market_data)

if __name__ == '__main__':
    if not os.path.exists(UPLOAD_FOLDER):
        os.makedirs(UPLOAD_FOLDER)
    app.run(debug=True)