from flask import Flask, render_template
import pandas as pd
import os
from datetime import datetime, timedelta

app = Flask(__name__)

CSV_FILE = "predictions_blended.csv"

# Check if CSV exists
if not os.path.exists(CSV_FILE):
    raise FileNotFoundError(f"⚠️ {CSV_FILE} not found.")

# Load CSV
stock_data = pd.read_csv(CSV_FILE)
stock_data.columns = [c.lower() for c in stock_data.columns]

@app.route("/")
def index():
    """
    Main page: show table of all stocks with search box
    """
    return render_template("stocks_table.html", stocks=stock_data.to_dict(orient="records"))

@app.route("/stock/<symbol>")
def stock_graph(symbol):
    """
    Stock page: show historical price graph + prediction text + prediction graph
    """
    stock_row = stock_data[stock_data["symbol"].str.upper() == symbol.upper()]
    if stock_row.empty:
        return f"No data for {symbol}"

    row = stock_row.iloc[0]

    # --- Historical data (dummy) ---
    historical_days = 10
    last_close = row["last_close"]
    dates = [(datetime.today() - timedelta(days=i)).strftime("%Y-%m-%d") for i in range(historical_days, 0, -1)]
    prices = [last_close * (0.98 + 0.004*i) for i in range(historical_days)]

    historical_chart = {
        "labels": dates,
        "values": prices
    }

    # --- Prediction data ---
    prediction_labels = ["Next Day", "1 Month", "1 Year"]
    prediction_values = [row["next_day_prediction"], row["1_month_prediction"], row["1_year_prediction"]]

    prediction_chart = {
        "labels": prediction_labels,
        "values": prediction_values
    }

    return render_template("stock_graph.html",
                           stock=row,
                           historical_chart=historical_chart,
                           prediction_chart=prediction_chart)

if __name__ == "__main__":
    app.run(debug=True)
