import os
import pandas as pd
import numpy as np
from prophet import Prophet
from sklearn.preprocessing import MinMaxScaler
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import LSTM, Dense

# --- CONFIG ---
DATA_FOLDER = "stock_data"
OUTPUT_FILE = "predictions_blended.csv"
FORECAST_HORIZONS = {"Next_Day": 1, "1_Month": 30, "1_Year": 365}

# --- FUNCTION TO CREATE LSTM DATA ---
def create_lstm_data(series, time_steps=5):
    X, y = [], []
    for i in range(len(series) - time_steps):
        X.append(series[i:i+time_steps])
        y.append(series[i+time_steps])
    return np.array(X), np.array(y)

# --- FUNCTION TO TRAIN LSTM AND PREDICT ---
def lstm_forecast(series, n_forecast):
    if len(series) < 6:  # need at least time_steps + 1 data points
        return np.array([series[-1]] * n_forecast)
    
    scaler = MinMaxScaler()
    series_scaled = scaler.fit_transform(series.reshape(-1,1))

    time_steps = 5
    X, y = create_lstm_data(series_scaled, time_steps)
    X = X.reshape((X.shape[0], X.shape[1], 1))

    # Stable LSTM model
    model = Sequential()
    model.add(LSTM(50, activation='tanh', input_shape=(time_steps,1)))
    model.add(Dense(1))
    model.compile(optimizer='adam', loss='mse')
    model.fit(X, y, epochs=50, batch_size=8, verbose=0)

    lstm_input = series_scaled[-time_steps:].reshape(1, time_steps, 1)
    lstm_predictions = []

    for _ in range(n_forecast):
        pred = model.predict(lstm_input, verbose=0)
        pred = np.clip(pred, 0, 1)  # prevent overflow
        lstm_predictions.append(pred[0,0])
        pred_reshaped = pred.reshape(1,1,1)
        lstm_input = np.append(lstm_input[:,1:,:], pred_reshaped, axis=1)

    lstm_predictions = np.array(lstm_predictions).reshape(-1,1)
    lstm_predictions = scaler.inverse_transform(lstm_predictions)
    return lstm_predictions.flatten()

# --- MAIN LOOP ---
final_data = []

for file in os.listdir(DATA_FOLDER):
    if file.endswith(".csv"):
        stock_name = file.split(".csv")[0]
        try:
            df = pd.read_csv(os.path.join(DATA_FOLDER, file))
        except Exception as e:
            print(f"[SKIP] {stock_name}: Could not read file ({e})")
            continue

        # Check required columns
        if 'Date' not in df.columns or 'Close' not in df.columns:
            print(f"[SKIP] {stock_name}: Missing required columns")
            continue

        # Clean data
        df = df[['Date','Close']].dropna()
        df['Date'] = pd.to_datetime(df['Date'], errors='coerce').dt.tz_localize(None)
        df = df.dropna().sort_values('Date')

        if df.empty:
            print(f"[SKIP] {stock_name}: No valid data after cleaning")
            continue

        last_close = df['Close'].iloc[-1]

        blended_forecasts = {}

        # Train Prophet once per stock
        prophet_df = df.rename(columns={'Date':'ds','Close':'y'})
        try:
            model_prophet = Prophet(daily_seasonality=True)
            model_prophet.fit(prophet_df)
        except Exception as e:
            print(f"[SKIP] {stock_name}: Prophet training failed ({e})")
            continue

        # Forecast horizons
        for horizon_name, horizon_days in FORECAST_HORIZONS.items():
            # Prophet forecast
            future = model_prophet.make_future_dataframe(periods=horizon_days)
            forecast_prophet = model_prophet.predict(future)['yhat'][-horizon_days:].values

            # LSTM forecast
            lstm_pred = lstm_forecast(df['Close'].values, horizon_days)

            # Blended forecast (average of last predicted value)
            blended_forecasts[horizon_name] = (forecast_prophet[-1] + lstm_pred[-1]) / 2

        final_data.append({
            "Symbol": stock_name,
            "Last_Close": last_close,
            "Next_Day_Prediction": blended_forecasts["Next_Day"],
            "1_Month_Prediction": blended_forecasts["1_Month"],
            "1_Year_Prediction": blended_forecasts["1_Year"]
        })

# --- SAVE TO CSV ---
if final_data:
    final_df = pd.DataFrame(final_data)
    final_df.to_csv(OUTPUT_FILE, index=False)
    print(f"[✅] All blended forecasts saved in {OUTPUT_FILE}")
else:
    print("[⚠️] No valid data found. CSV not created.")
