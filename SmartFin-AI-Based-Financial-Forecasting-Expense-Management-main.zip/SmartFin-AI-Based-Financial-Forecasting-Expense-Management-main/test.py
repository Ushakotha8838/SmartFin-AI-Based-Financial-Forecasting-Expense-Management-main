from flask import Flask, render_template
import pandas as pd

app = Flask(__name__)

@app.route('/')
def index():
    # Read the predictions CSV
    df = pd.read_csv('stock_predictions.csv')
    # Convert to a list of dictionaries for easy rendering
    stocks = df.to_dict(orient='records')
    return render_template('test.html', stocks=stocks)

if __name__ == '__main__':
    app.run(debug=True)
